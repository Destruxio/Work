import { translateDom } from '../i18n/i18n.service.js';

const initializeOptions = () => {
  translateDom();
};

initializeOptions();
